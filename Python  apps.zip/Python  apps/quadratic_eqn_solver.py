import math


def quadratic_eqn_solver(a, b, c):
    try:
        x = ''

        x_1 = ((-b) + math.sqrt((b ** 2) - (4 * a * c))) / (2 * a)
        x_2 = ((-b) - math.sqrt((b ** 2) - (4 * a * c))) / (2 * a)
        x += f'x = {round(x_1, 3)}  or   {round(x_2, 3)}'
        print(x)
    except ValueError:
        print('The values of x are imaginary for this equation')



quadratic_eqn_solver(1,5,6)

print('Manually input your values for a,b and c')


def quadratic_solver():
    try:
        x = ''
        a = float(input('a'))
        b = float(input('b'))
        c = float(input('c'))
        x_1 = ((-b) + math.sqrt((b ** 2) - (4 * a * c))) / (2 * a)
        x_2 = ((-b) - math.sqrt((b ** 2) - (4 * a * c))) / (2 * a)
        x += f'x = {round(x_1, 3)}  or   {round(x_2, 3)}'
        print(x)
    except ValueError:
        print('The values of x are imaginary for this equation')


quadratic_solver()
