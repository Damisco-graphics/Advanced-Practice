weight = input("What's your weight")
unit = input("Unit").upper()

if unit == 'L':
    converted_weight=float(weight)*0.45
    print(f'You are {converted_weight} kilos')
elif unit=='K':
    converted_weight=float(weight)/0.45
    print(f'You are {converted_weight} pounds')

else:
    print('Incorrect unit')

